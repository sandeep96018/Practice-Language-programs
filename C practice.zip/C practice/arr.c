#include<stdio.h>
int main()
{
	int i=0;
	int arr[6]={11,22,33,44,55,66};
	for(i=0;i<6;i++)
	{
		printf(" %d \n",arr[i]);
	}
}
