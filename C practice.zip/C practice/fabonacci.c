#include<stdio.h>

int main(){
     int n1=0,n2=1,n3,number;
     printf("Enter number till you want to fabonacci series");
     scanf("%d",&number);
     printf("%d %d ",n1,n2);
     for(int i=2;i<number;i++)
     { 
        n3=n1+n2;
        n3=n2;
        n2=n1;
     }
     return 0 ; 
}
