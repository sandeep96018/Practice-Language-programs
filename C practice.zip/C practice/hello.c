#include<stdio.h>

int main(){
     int number;
     printf("Enter number till you want to fabonacci series");
     scanf("%d",&number);
     printf("%d",number);
        
}
