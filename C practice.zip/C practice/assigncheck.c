#include<stdio.h>
int main()
{
	int a = 11,2,3,4,85;
	printf("%d",a);
}
