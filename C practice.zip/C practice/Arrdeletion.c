#include<stdio.h>
void traversal(int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf(" %d ",arr[i]);
	}
	printf("\n");
}

void indexDeletion(int arr[],int size,int index)
{
	int i;
	
	for(i=index;i<size;i++)
	{
		arr[i]=arr[i+1];
	}
}
int main()
{
	int size=5;
	int index=0;
	int arr[100]={1,2,3,4,5};
	traversal(arr,size);
	indexDeletion(arr,size,index);
	size-=1;
	traversal(arr,size);
	
	return 0;
	
}
