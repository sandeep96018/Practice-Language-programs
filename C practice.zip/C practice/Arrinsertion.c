#include<stdio.h>
void traversal(int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf(" %d ",arr[i]);
	}
	printf("\n");
}

int indexInsertion(int arr[],int size,int element,int capacity,int index)
{
	int i;
	if(size>=capacity)
	{
		return -1;
	}
	for(i=size-1;i>=index;i--)
	{
		arr[i+1]=arr[i];
	}
	arr[index]=element;
//	size=size+1;
	return 1;
}
int main()
{
	int size=5;
	int index=3,element=4000;
	int arr[100]={1,2,3,4,5};
	traversal(arr,size);
	indexInsertion(arr,size,element,100,index);
	size+=1;
	traversal(arr,size);
	printf("\n\n%d",size);
	
	return 0;
	
}
