#include<stdio.h>
#include<conio.h>

struct Node
{
	int data;
	struct Node * left;
	struct Node * right;
};

struct Node * newNode(int item)
{
	struct Node * temp = (struct Node *)malloc(sizeof(struct Node));
	temp->data=item;
	temp->left = NULL;
	temp->right = NULL;
	return temp;
}

void inorder(struct Node * root)
{
	if(root!=NULL)
	{
		inorder(root->left);
		printf("%d->",root->data);
		inorder(root->right);
	}
}
struct Node * insert(struct Node * node,int item)
{
		if(node==NULL)
		return newNode(item);
		
		if(item<node->data)
			node->left = insert(node->left,item);
		else
			node->right = insert(node->right,item);
}

int main()
{
	struct Node *root=NULL;
	root = insert(root,8);
	root = insert(root,18);
	root = insert(root,5);
	root = insert(root,10);
	root = insert(root,15);
	inorder(root);
	return 0;
}
