#include<stdio.h>
#include<conio.h>

int main(){
     struct employee
     {
         int id;
         char name[20];
         float salary;
        int long  mobile;
         

     };
     struct employee e1,e2;
     printf("Enter the id ,name ,salary and mobile number of firsst employee \n");
     scanf("%d %s %f %d",&e1.id,&e1.name,&e1.salary,&e1.mobile);
     printf("Enter the id ,name ,salary and mobile number of Second employee\n");
     scanf("%d %s %f %d",&e2.id,&e2.name,&e2.salary,&e2.mobile);

     printf("the name details of first employeeis is below \n");
     printf("id=%d \n name=%s\n,salary=%f \n  mobile number= %d \n \n",e1.id,e1.name,e1.salary,e1.mobile);

     printf("the name details of Second employeeis is below \n");
     printf("id=%d \n name=%s \n salary=%f \n  mobile number= %d \n",e2.id,e2.name,e2.salary,e2.mobile);
     return 0;
}

