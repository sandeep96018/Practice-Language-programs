#include<stdio.h>

int main(){
     int a=5;
     int *b;
     int **c;
     float d;
     char e;
     b=&a;
     c=&b;
     printf("The Adress of a= %d \n",&a);
     printf("The Adress of a= %d \n",&b);
     printf("The Adress of a= %d \n",&c);
     printf("The Adress of a= %d \n",b);
     printf("The Adress of a= %d \n",c);
     printf("The Value of askjkk= %d \n",*c);



     printf("The Adress of a= %d \n",sizeof(a));
     return 0;
}
