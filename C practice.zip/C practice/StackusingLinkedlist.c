#include<stdio.h>
#include<conio.h>

struct Node
{
	int data;
	struct Node * next;
};


int isEmpty(struct Node * top)
{
	if(top==NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int isFull(struct Node * top)
{
	struct Node * p = (struct Node *)malloc(sizeof(struct Node));
	if(p==NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	
}
void linkedListTraversal(struct Node * ptr)
{
	while(ptr!=NULL)
	{
		printf("Element= %d \n",ptr->data);
		ptr=ptr->next;
	}
}
struct Node * push(struct Node * top,int data)
{
	if(isFull(top))
	{
		printf("Stack overflow");
	}
	else
	{
		struct Node * p = (struct Node *)malloc(sizeof(struct Node));
		p->data=data;
		p->next = top;
		top = p;
		return top;
		
		
	}
}

int pop(struct Node ** top)
{
	if(isEmpty(*top))
	{
		printf("Stack underflow");
	}
	else
	{
		struct Node * p =*top;
		*top = (*top)->next;
		int x = p->data;
		free(p);
		return x;
	}
}
int main()
{
	struct Node * top = NULL;
	top=push(top,88);
	top=push(top,89);
	top=push(top,90);
	linkedListTraversal(top);
	int element =pop(&top);
	printf("The deleted eliment is %d \n",element);
	int element1 =pop(&top);
	printf("The deleted eliment is %d \n",element1);
	int element2 =pop(&top);
	printf("The deleted eliment is %d \n",element2);
//	int element3 =pop(&top);
//	printf("The deleted eliment is %d \n",element3);
	linkedListTraversal(top);
	return 0;
}
