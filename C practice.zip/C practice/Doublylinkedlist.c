#include<stdio.h>
#include<stdlib.h>
struct Node
{
	struct Node * prev;
	int data;
	struct Node *next;
};

struct Node * linkedListTraversal(struct Node * head)
{
	struct Node * p = head;
	while(p!=NULL)
	{
		printf(" %d \n",p->data);
		p=p->next;
	}
	return head;
}

struct Node * insertAtFirst(struct Node * head,int data)
{
	struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
	ptr->data=data;
	ptr->prev=NULL;
	
	ptr->next=head;
	head=ptr;
	return head;
}

struct Node * insertAtEnd(struct Node * head,int data)
{
	struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
	struct Node * p = head;
	ptr->data=data;
	
	while(p->next!=NULL)
	{ 
		p=p->next;
	}
	p->next = ptr;
	ptr->prev = p;
	ptr->next=NULL;
	return head;
}

int main()
{
	struct Node * head;
	head=(struct Node * )malloc(sizeof(struct Node));
	
	struct Node * second;
	second=(struct Node *)malloc(sizeof(struct Node));
	
	struct Node * third;
	third=(struct Node *)malloc(sizeof(struct Node));	
	
	struct Node * fourth;
	fourth=(struct Node *)malloc(sizeof(struct Node));
	
	head->prev=NULL;
	head->data=10;
	head->next=second;
	
	second->prev=head;
	second->data=20;
	second->next=third;
	
	third->prev=second;
	third->data=30;
	third->next=fourth;
	
	fourth->prev=third;
	fourth->data=40;
	fourth->next=NULL;
	
	printf("The Doubly linked list as below- \n");
	head = linkedListTraversal(head);
//	head = insertAtFirst(head,5);
	head = insertAtEnd(head,50);
	printf("\n");
	printf("The Doubly linked list after insertion- \n");
	head = linkedListTraversal(head);
	
	return 0;
}
