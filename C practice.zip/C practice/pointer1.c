#include<stdio.h>

int main(){
    int a=5;
    int *b;
    b=&a;
    printf("The value ofa= %d \n",a);
    printf("The value ofa= %d \n",*(&a));
    printf("The value ofa= %d \n",*b);
    printf("The value of b= %u \n",b);
    printf("The value of b= %d \n",&b);
     
     return 0;
}
